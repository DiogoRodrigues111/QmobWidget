/****************************************************************************
** Meta object code from reading C++ file 'widget.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.15.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../atividade1/widget.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'widget.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.15.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_S_P2D_Coord_t {
    QByteArrayData data[3];
    char stringdata0[16];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_S_P2D_Coord_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_S_P2D_Coord_t qt_meta_stringdata_S_P2D_Coord = {
    {
QT_MOC_LITERAL(0, 0, 11), // "S_P2D_Coord"
QT_MOC_LITERAL(1, 12, 1), // "x"
QT_MOC_LITERAL(2, 14, 1) // "y"

    },
    "S_P2D_Coord\0x\0y"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_S_P2D_Coord[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       2,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, QMetaType::Float, 0x00095003,
       2, QMetaType::Float, 0x00095003,

       0        // eod
};

void S_P2D_Coord::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        auto *_t = reinterpret_cast<S_P2D_Coord *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< float*>(_v) = _t->x; break;
        case 1: *reinterpret_cast< float*>(_v) = _t->y; break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = reinterpret_cast<S_P2D_Coord *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0:
            if (_t->x != *reinterpret_cast< float*>(_v)) {
                _t->x = *reinterpret_cast< float*>(_v);
            }
            break;
        case 1:
            if (_t->y != *reinterpret_cast< float*>(_v)) {
                _t->y = *reinterpret_cast< float*>(_v);
            }
            break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject S_P2D_Coord::staticMetaObject = { {
    nullptr,
    qt_meta_stringdata_S_P2D_Coord.data,
    qt_meta_data_S_P2D_Coord,
    qt_static_metacall,
    nullptr,
    nullptr
} };

struct qt_meta_stringdata_Player_t {
    QByteArrayData data[9];
    char stringdata0[103];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Player_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Player_t qt_meta_stringdata_Player = {
    {
QT_MOC_LITERAL(0, 0, 6), // "Player"
QT_MOC_LITERAL(1, 7, 11), // "playerClass"
QT_MOC_LITERAL(2, 19, 11), // "PlayerClass"
QT_MOC_LITERAL(3, 31, 5), // "speed"
QT_MOC_LITERAL(4, 37, 4), // "ammo"
QT_MOC_LITERAL(5, 42, 9), // "is_active"
QT_MOC_LITERAL(6, 52, 25), // "numberAccumulationOfCoord"
QT_MOC_LITERAL(7, 78, 11), // "S_P2D_Coord"
QT_MOC_LITERAL(8, 90, 12) // "S_P2D_Coord*"

    },
    "Player\0playerClass\0PlayerClass\0speed\0"
    "ammo\0is_active\0numberAccumulationOfCoord\0"
    "S_P2D_Coord\0S_P2D_Coord*"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Player[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       6,   14, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       4,       // flags
       0,       // signalCount

 // properties: name, type, flags
       1, 0x80000000 | 2, 0x0009500b,
       3, QMetaType::Float, 0x00095003,
       4, QMetaType::UShort, 0x00095003,
       5, QMetaType::Bool, 0x00095003,
       6, QMetaType::UChar, 0x00095003,
       7, 0x80000000 | 8, 0x0009500b,

       0        // eod
};

void Player::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{

#ifndef QT_NO_PROPERTIES
    if (_c == QMetaObject::ReadProperty) {
        auto *_t = reinterpret_cast<Player *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0: *reinterpret_cast< PlayerClass*>(_v) = _t->playerClass; break;
        case 1: *reinterpret_cast< float*>(_v) = _t->speed; break;
        case 2: *reinterpret_cast< unsigned short*>(_v) = _t->ammo; break;
        case 3: *reinterpret_cast< bool*>(_v) = _t->is_active; break;
        case 4: *reinterpret_cast< unsigned char*>(_v) = _t->numberAccumulationOfCoord; break;
        case 5: *reinterpret_cast< S_P2D_Coord**>(_v) = _t->pP2DCoord; break;
        default: break;
        }
    } else if (_c == QMetaObject::WriteProperty) {
        auto *_t = reinterpret_cast<Player *>(_o);
        Q_UNUSED(_t)
        void *_v = _a[0];
        switch (_id) {
        case 0:
            if (_t->playerClass != *reinterpret_cast< PlayerClass*>(_v)) {
                _t->playerClass = *reinterpret_cast< PlayerClass*>(_v);
            }
            break;
        case 1:
            if (_t->speed != *reinterpret_cast< float*>(_v)) {
                _t->speed = *reinterpret_cast< float*>(_v);
            }
            break;
        case 2:
            if (_t->ammo != *reinterpret_cast< unsigned short*>(_v)) {
                _t->ammo = *reinterpret_cast< unsigned short*>(_v);
            }
            break;
        case 3:
            if (_t->is_active != *reinterpret_cast< bool*>(_v)) {
                _t->is_active = *reinterpret_cast< bool*>(_v);
            }
            break;
        case 4:
            if (_t->numberAccumulationOfCoord != *reinterpret_cast< unsigned char*>(_v)) {
                _t->numberAccumulationOfCoord = *reinterpret_cast< unsigned char*>(_v);
            }
            break;
        case 5:
            if (_t->pP2DCoord != *reinterpret_cast< S_P2D_Coord**>(_v)) {
                _t->pP2DCoord = *reinterpret_cast< S_P2D_Coord**>(_v);
            }
            break;
        default: break;
        }
    } else if (_c == QMetaObject::ResetProperty) {
    }
#endif // QT_NO_PROPERTIES
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject Player::staticMetaObject = { {
    nullptr,
    qt_meta_stringdata_Player.data,
    qt_meta_data_Player,
    qt_static_metacall,
    nullptr,
    nullptr
} };

struct qt_meta_stringdata_Widget_t {
    QByteArrayData data[1];
    char stringdata0[7];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_Widget_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_Widget_t qt_meta_stringdata_Widget = {
    {
QT_MOC_LITERAL(0, 0, 6) // "Widget"

    },
    "Widget"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_Widget[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       0,    0, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

       0        // eod
};

void Widget::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    Q_UNUSED(_o);
    Q_UNUSED(_id);
    Q_UNUSED(_c);
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject Widget::staticMetaObject = { {
    QMetaObject::SuperData::link<QScrollArea::staticMetaObject>(),
    qt_meta_stringdata_Widget.data,
    qt_meta_data_Widget,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *Widget::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *Widget::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_Widget.stringdata0))
        return static_cast<void*>(this);
    return QScrollArea::qt_metacast(_clname);
}

int Widget::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QScrollArea::qt_metacall(_c, _id, _a);
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
